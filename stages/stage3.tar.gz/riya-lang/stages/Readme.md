## Stages

This project was originally forked from Tiny Lang, and as such some improvements may want to be merged back to that compiler or eventually spun off into a new compiler. This folder contains snapshots of this compiler in various stages as improvements are being made.

Timeline:
* Stage 1- initial snapshot with testing in place, a new standard library, and significant changes and upgrades are made. Still language compatible with Tiny Lang.
* Stage 2- Snapshot with working LLIR and AS built-in- partially working complete toolchain

