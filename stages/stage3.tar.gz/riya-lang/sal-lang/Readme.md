## Set Arithmetic Language

This is a language based on set theory and airthmetic operations.

