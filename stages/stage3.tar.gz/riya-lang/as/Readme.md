## Assemblers

This is a collection of assemblers for various platforms. Currently, we have x86-64 and RISC-V (32). 

Note that the RISC-V assembler generates the complete base instruction integer set and some extensions, but it generates flat binaries. We plan to add ELF support in the near future.

